# ハンガリー現役生名鑑（MVP v1.0）

Next.js + Supabase + Stripe + Resend で **「サイト内完結」** の最小MVPを動かすテンプレです。

## できること（MVP）
- 志願者：現役生を検索 → プロフィール → 空き枠（日本時間表示）→ 事前質問 → Stripe決済 → 予約確定
- 現役生：メールのマジックリンクでログイン → 空き枠を（ハンガリー時間で）登録・削除
- 運営：予約一覧を確認（簡易）

## 事前に作るもの
1. Supabase プロジェクト
2. Stripe アカウント
3. Resend（またはSendGrid等）

## Supabase 設定
### 1) SQLを流す
Supabase → SQL Editor で `supabase/schema.sql` を実行。

### 2) Storage（アバター）
Supabase → Storage で bucket `avatars` を作り、Public にする（MVP）

### 3) Auth
Supabase → Auth → Providers で Email を有効（OTP / Magic link）。
Site URL を `NEXT_PUBLIC_SITE_URL` に合わせる。

## Stripe 設定
1. Stripe Dashboard で API Key を取得
2. Webhook を追加
- Endpoint: `https://あなたのドメイン/api/stripe/webhook`
- Event: `checkout.session.completed`
3. Webhook Signing Secret を取得

## Resend 設定
- API Key を取得
- 送信元ドメインを設定（できなければ一旦 dev でOK）

## 環境変数
`.env.example` を `.env.local` にコピーして埋める：

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `NEXT_PUBLIC_SITE_URL`
- `RESEND_API_KEY`
- `MAIL_FROM`
- `ADMIN_TOKEN`（任意）

## 起動
```bash
npm install
npm run dev
```

## デプロイ（Vercel推奨）
1. GitHub にpush
2. Vercel で Import
3. Env Vars を Vercel に同じく設定
4. Stripe Webhook の URL を Vercel のURLに更新

---

## 「現役生を追加」最短
- まず運営が Supabase の `tutors` テーブルに1人目（自分）をINSERT（SQL or Table Editor）
- そのメールで `/login` からマジックリンクログイン
- `/dashboard` でプロフィールと空き枠を編集

> 現役生が自分で編集できる設計なので、運営が毎回DBを触る必要はありません。
