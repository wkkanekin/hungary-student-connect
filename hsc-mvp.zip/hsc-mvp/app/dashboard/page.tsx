import { supabaseServer } from '@/lib/supabase-server'
import { redirect } from 'next/navigation'
import { Dashboard } from '@/components/dashboard'

export default async function DashboardPage() {
  const supabase = supabaseServer()
  const { data } = await supabase.auth.getUser()
  const user = data.user
  if (!user) redirect('/login')

  return <Dashboard email={user.email || ''} />
}
