import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { z } from 'zod'
import { env } from '@/lib/env'
import { supabaseAdmin } from '@/lib/supabase-admin'

const bodySchema = z.object({
  slotId: z.string().min(1),
  applicantName: z.string().min(1),
  applicantEmail: z.string().email(),
  topics: z.array(z.string()).default([]),
  applicantNote: z.string().optional().default(''),
  applicantStatus: z.string().optional().default(''),
})

export async function POST(req: Request) {
  try {
    if (!env.STRIPE_SECRET_KEY || !env.NEXT_PUBLIC_APP_URL) {
      return NextResponse.json({ error: 'Stripe/APP_URL が未設定です' }, { status: 500 })
    }
    const json = await req.json()
    const body = bodySchema.parse(json)

    const supabase = supabaseAdmin()

    // slot確認
    const { data: slot, error: sErr } = await supabase
      .from('availability_slots')
      .select('*')
      .eq('id', body.slotId)
      .single()
    if (sErr || !slot) return NextResponse.json({ error: '空き枠が見つかりません' }, { status: 404 })
    if (slot.status !== 'open') return NextResponse.json({ error: 'この枠はすでに予約済みです' }, { status: 400 })

    // tutor確認（メール送信用）
    const { data: tutor, error: tErr } = await supabase
      .from('tutors')
      .select('id,name,email')
      .eq('id', slot.tutor_id)
      .single()
    if (tErr || !tutor) return NextResponse.json({ error: '現役生が見つかりません' }, { status: 404 })

    // reservation作成（pending）
    const { data: reservation, error: rErr } = await supabase
      .from('reservations')
      .insert({
        tutor_id: slot.tutor_id,
        slot_id: slot.id,
        applicant_name: body.applicantName,
        applicant_email: body.applicantEmail,
        applicant_note: body.applicantNote,
        applicant_status: body.applicantStatus,
        topics: body.topics,
        status: 'pending_payment'
      })
      .select('*')
      .single()
    if (rErr || !reservation) return NextResponse.json({ error: '予約作成に失敗しました' }, { status: 500 })

    const stripe = new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' })

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'jpy',
            product_data: {
              name: `オンライン相談 60分（${tutor.name}）`,
            },
            unit_amount: 8000 * 100,
          },
          quantity: 1,
        },
      ],
      success_url: `${env.NEXT_PUBLIC_APP_URL}/complete/${reservation.id}`,
      cancel_url: `${env.NEXT_PUBLIC_APP_URL}/tutors/${tutor.id}`,
      metadata: {
        reservation_id: reservation.id,
        slot_id: slot.id,
        tutor_id: tutor.id,
        tutor_email: tutor.email || '',
        applicant_email: body.applicantEmail,
      },
    })

    await supabase
      .from('reservations')
      .update({ stripe_session_id: session.id })
      .eq('id', reservation.id)

    return NextResponse.json({ url: session.url })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'unknown error' }, { status: 400 })
  }
}
