import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { env } from '@/lib/env'
import { supabaseAdmin } from '@/lib/supabase-admin'
import { Resend } from 'resend'

export const runtime = 'nodejs'

const stripe = new Stripe(env.STRIPE_SECRET_KEY || '', { apiVersion: '2024-06-20' })

export async function POST(req: Request) {
  if (!env.STRIPE_WEBHOOK_SECRET) return new NextResponse('STRIPE_WEBHOOK_SECRET missing', { status: 500 })

  const sig = headers().get('stripe-signature') || ''
  const buf = await req.arrayBuffer()
  const body = Buffer.from(buf)

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(body, sig, env.STRIPE_WEBHOOK_SECRET)
  } catch (err: any) {
    return new NextResponse(`Webhook error: ${err.message}`, { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session
    const reservationId = session.metadata?.reservation_id
    const slotId = session.metadata?.slot_id

    if (!reservationId || !slotId) {
      return new NextResponse('Missing metadata', { status: 400 })
    }

    const supabase = supabaseAdmin()

    // Confirm reservation + book slot (idempotent)
    await supabase.from('availability_slots').update({ status: 'booked' }).eq('id', slotId)
    await supabase
      .from('reservations')
      .update({ status: 'confirmed', paid_at: new Date().toISOString() })
      .eq('id', reservationId)

    // fetch details for email
    const { data: r } = await supabase
      .from('reservations')
      .select('id,applicant_name,applicant_email,topics,applicant_note,tutor_id,slot_id')
      .eq('id', reservationId)
      .maybeSingle()

    const { data: slot } = await supabase
      .from('availability_slots')
      .select('start_at_utc,end_at_utc')
      .eq('id', slotId)
      .maybeSingle()

    const { data: tutor } = r?.tutor_id
      ? await supabase.from('tutors').select('name,email').eq('id', r.tutor_id).maybeSingle()
      : { data: null }

    if (env.RESEND_API_KEY && env.FROM_EMAIL && r && slot) {
      const resend = new Resend(env.RESEND_API_KEY)
      const subject = '【予約確定】ハンガリー現役生名鑑（ベータ版）'
      const htmlApplicant = `
        <p>${r.applicant_name} 様</p>
        <p>ご予約が確定しました。</p>
        <p><b>予約ID:</b> ${r.id}</p>
        <p><b>現役生:</b> ${tutor?.name ?? ''}</p>
        <p><b>日時(UTC保存):</b> ${slot.start_at_utc}（開始）</p>
        <p>当日の連絡手段（Zoom/LINE）は、現役生から連絡します（MVP）。</p>
        <hr />
        <p><b>事前質問テーマ:</b> ${(r.topics || []).join(' / ')}</p>
        <p><b>自由記述:</b> ${escapeHtml(r.applicant_note || '')}</p>
      `

      await resend.emails.send({
        from: env.FROM_EMAIL,
        to: r.applicant_email,
        subject,
        html: htmlApplicant,
      })

      if (tutor?.email) {
        const htmlTutor = `
          <p>${tutor.name} 様</p>
          <p>予約が入りました（確定）。</p>
          <p><b>予約ID:</b> ${r.id}</p>
          <p><b>志願者:</b> ${r.applicant_name}（${r.applicant_email}）</p>
          <p><b>開始(UTC保存):</b> ${slot.start_at_utc}</p>
          <hr />
          <p><b>事前質問テーマ:</b> ${(r.topics || []).join(' / ')}</p>
          <p><b>自由記述:</b> ${escapeHtml(r.applicant_note || '')}</p>
        `
        await resend.emails.send({
          from: env.FROM_EMAIL,
          to: tutor.email,
          subject,
          html: htmlTutor,
        })
      }
    }
  }

  return NextResponse.json({ received: true })
}

function escapeHtml(s: string) {
  return s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}
