import { fetchSlot } from '@/lib/db'
import { supabaseServer } from '@/lib/supabase-server'
import { BookingForm } from '@/components/booking-form'
import { Card } from '@/components/ui'
import { TZ_HU, TZ_JST } from '@/lib/time'
import { formatInTimeZone } from 'date-fns-tz'

export default async function BookPage({ params }: { params: { slotId: string } }) {
  const slot = await fetchSlot(params.slotId)
  const supabase = supabaseServer()
  const { data: tutor } = await supabase
    .from('tutors')
    .select('id,name,university')
    .eq('id', slot.tutor_id)
    .single()

  const start = new Date(slot.start_at_utc)
  const end = new Date(slot.end_at_utc)
  const j = `${formatInTimeZone(start, TZ_JST, 'M/d(EEE) HH:mm')}–${formatInTimeZone(end, TZ_JST, 'HH:mm')}`
  const h = `${formatInTimeZone(start, TZ_HU, 'HH:mm')}–${formatInTimeZone(end, TZ_HU, 'HH:mm')}`

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-black">予約確認</h1>
        <p className="mt-1 text-slate-600">この内容で予約し、事前決済（8,000円）を行います。</p>
      </div>

      <Card>
        <div className="font-extrabold">予約内容</div>
        <div className="mt-2 text-sm text-slate-700">
          <div><span className="font-bold">相談相手：</span>{tutor?.name}（{tutor?.university}）</div>
          <div className="mt-1"><span className="font-bold">日時：</span>{j}（日本） / {h}（ハンガリー）</div>
          <div className="mt-1"><span className="font-bold">所要時間：</span>60分</div>
          <div className="mt-1"><span className="font-bold">料金：</span>8,000円（税込）</div>
          <div className="mt-2 text-xs text-slate-500">※表示は日本時間（JST）です。現役生側の画面はブダペスト時間です。</div>
        </div>
      </Card>

      <Card>
        <div className="font-extrabold">事前質問</div>
        <p className="mt-1 text-sm text-slate-600">現役生が準備して臨めるように、可能な範囲で入力してください（書けない項目は空欄でOK）。</p>
        <div className="mt-4">
          <BookingForm slotId={params.slotId} tutorName={tutor?.name ?? ''} />
        </div>
      </Card>

      <Card>
        <div className="font-extrabold">返金ポリシー（MVP）</div>
        <ul className="mt-2 list-disc pl-5 text-sm text-slate-700">
          <li>現役生側の都合で実施できない場合：全額返金</li>
          <li>志願者都合キャンセル：原則不可（明記）</li>
        </ul>
      </Card>
    </div>
  )
}
