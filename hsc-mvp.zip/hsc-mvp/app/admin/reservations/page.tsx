import { env } from '@/lib/env'
import { supabaseAdmin } from '@/lib/supabase-admin'
import { Card } from '@/components/ui'

export default async function AdminReservationsPage({ searchParams }: { searchParams: { token?: string } }) {
  const token = searchParams.token || ''
  const required = env.ADMIN_TOKEN || ''
  if (required && token !== required) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-black">予約一覧（運営）</h1>
        <Card>
          <p className="text-slate-600">アクセスが拒否されました。URLに ?token=... を付けてください。</p>
        </Card>
      </div>
    )
  }

  const sb = supabaseAdmin()
  const { data, error } = await sb
    .from('reservations')
    .select('id, status, applicant_name, applicant_email, paid_at, created_at, tutor_id, slot_id')
    .order('created_at', { ascending: false })
    .limit(200)

  if (error) {
    return <div>error: {error.message}</div>
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-black">予約一覧（運営）</h1>
      <Card>
        <div className="overflow-auto">
          <table className="min-w-[900px] w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-2">日時</th>
                <th>志願者</th>
                <th>メール</th>
                <th>status</th>
                <th>tutor_id</th>
                <th>slot_id</th>
              </tr>
            </thead>
            <tbody>
              {(data || []).map((r) => (
                <tr key={r.id} className="border-t border-slate-200">
                  <td className="py-2 whitespace-nowrap">{new Date(r.created_at).toLocaleString()}</td>
                  <td className="whitespace-nowrap">{r.applicant_name}</td>
                  <td className="whitespace-nowrap">{r.applicant_email}</td>
                  <td className="whitespace-nowrap">{r.status}</td>
                  <td className="whitespace-nowrap">{r.tutor_id}</td>
                  <td className="whitespace-nowrap">{r.slot_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
