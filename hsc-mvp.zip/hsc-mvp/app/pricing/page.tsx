import { Card, LinkButton } from '@/components/ui'

export default function PricingPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black">料金</h1>
        <p className="mt-1 text-slate-600">単発 60分（8,000円）。まずは1回だけ相談したい方向けのMVPです。</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <div className="text-sm font-bold text-slate-500">単発（60分）</div>
          <div className="mt-2 flex items-baseline gap-2">
            <div className="text-4xl font-black">8,000</div>
            <div className="text-slate-500">円（税込）</div>
          </div>
          <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-slate-600">
            <li>空き枠を選んで予約 → 事前決済 → 即確定</li>
            <li>事前質問フォームで、聞きたいことを整理してから相談できます</li>
            <li>現役生都合で実施できない場合は全額返金</li>
          </ul>
          <div className="mt-5">
            <LinkButton href="/tutors" variant="primary">現役生を探す</LinkButton>
          </div>
        </Card>

        <Card className="bg-slate-50">
          <div className="font-extrabold">返金・キャンセル（MVP）</div>
          <p className="mt-2 text-sm text-slate-600">
            現役生側の都合で相談が実施できない場合は全額返金します。
            志願者都合のキャンセルは原則不可（無断キャンセル防止のため）とします。
          </p>
          <p className="mt-2 text-xs text-slate-500">※ベータ版のため運用は改善される可能性があります。</p>
        </Card>
      </div>

      <Card>
        <div className="font-extrabold">他社比較（一般的な例）</div>
        <p className="mt-1 text-sm text-slate-600">
          特定企業を名指しせず、「留学相談でよくある選択肢」を比較します（参考）。
        </p>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="border-b border-slate-200 p-3">項目</th>
                <th className="border-b border-slate-200 p-3">本サービス</th>
                <th className="border-b border-slate-200 p-3">留学エージェント相談（一般）</th>
                <th className="border-b border-slate-200 p-3">個別コンサル（一般）</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border-b border-slate-200 p-3 font-bold">料金感</td>
                <td className="border-b border-slate-200 p-3">8,000円 / 60分</td>
                <td className="border-b border-slate-200 p-3">無料〜（手続き前提の場合あり）</td>
                <td className="border-b border-slate-200 p-3">高め（数万円〜）</td>
              </tr>
              <tr>
                <td className="border-b border-slate-200 p-3 font-bold">情報の生々しさ</td>
                <td className="border-b border-slate-200 p-3">現地の現役生の体験談</td>
                <td className="border-b border-slate-200 p-3">一般情報中心</td>
                <td className="border-b border-slate-200 p-3">経験者・専門家による</td>
              </tr>
              <tr>
                <td className="border-b border-slate-200 p-3 font-bold">日程の取りやすさ</td>
                <td className="border-b border-slate-200 p-3">空き枠から即予約</td>
                <td className="border-b border-slate-200 p-3">担当者調整</td>
                <td className="border-b border-slate-200 p-3">担当者調整</td>
              </tr>
              <tr>
                <td className="border-b border-slate-200 p-3 font-bold">用途</td>
                <td className="border-b border-slate-200 p-3">不安の解消・現地のリアル確認</td>
                <td className="border-b border-slate-200 p-3">手続き全般の相談</td>
                <td className="border-b border-slate-200 p-3">戦略設計・書類添削など</td>
              </tr>
            </tbody>
          </table>
        </div>

        <p className="mt-3 text-xs text-slate-500">
          ※上記は一般的な傾向の例であり、各サービスや担当者によって異なります。
        </p>
      </Card>
    </div>
  )
}
