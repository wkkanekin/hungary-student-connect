import { fetchOpenSlotsForTutor, fetchTutorById } from '@/lib/db'
import { Badge, Card, LinkButton } from '@/components/ui'
import { TZ_HU, TZ_JST } from '@/lib/time'
import { formatInTimeZone } from 'date-fns-tz'

export default async function TutorDetailPage({ params }: { params: { id: string } }) {
  const tutor = await fetchTutorById(params.id)
  const slots = await fetchOpenSlotsForTutor(params.id)

  const grouped: Record<string, typeof slots> = {}
  for (const s of slots) {
    const key = formatInTimeZone(new Date(s.start_at_utc), TZ_JST, 'yyyy-MM-dd')
    ;(grouped[key] ??= []).push(s)
  }

  return (
    <div className="space-y-4">
      <div className="rounded-3xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-slate-900 text-white font-black">{tutor.name.slice(0, 1)}</div>
            <div>
              <h1 className="text-xl font-black">{tutor.name}</h1>
              <p className="mt-1 text-slate-600">{tutor.university}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge>{tutor.region === 'Budapest' ? 'ブダペスト' : '地方'}</Badge>
                <Badge>{tutor.course}</Badge>
                <Badge>{tutor.field}</Badge>
                <Badge>{tutor.social_exp ? '社会人経験あり' : '社会人経験なし'}</Badge>
                <Badge>{tutor.age_group}</Badge>
                {tutor.grade ? <Badge>{tutor.grade}</Badge> : null}
              </div>
            </div>
          </div>
          <LinkButton href="/tutors" variant="secondary">一覧へ戻る</LinkButton>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Card>
            <div className="text-xs font-bold text-slate-500">一言紹介</div>
            <p className="mt-1 text-slate-700">{tutor.bio}</p>
          </Card>
          <Card>
            <div className="text-xs font-bold text-slate-500">相談ジャンル</div>
            <div className="mt-2 flex flex-wrap gap-2">
              {tutor.tags.map((t) => (
                <span key={t} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-bold text-slate-700">
                  {t}
                </span>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <Card>
        <div className="flex flex-col gap-1">
          <div className="font-extrabold">空き枠（日本時間）</div>
          <div className="text-sm text-slate-600">※志願者には日本時間（JST）のみ表示します</div>
        </div>

        <div className="mt-4 space-y-4">
          {Object.keys(grouped).length === 0 ? (
            <p className="text-sm text-slate-600">現在、公開中の空き枠がありません。</p>
          ) : (
            Object.entries(grouped)
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([date, list]) => (
                <div key={date} className="rounded-2xl border border-slate-200 bg-white p-4">
                  <div className="text-sm font-extrabold text-slate-800">
                    {formatInTimeZone(new Date(list[0].start_at_utc), TZ_JST, 'M/d(EEE)')}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {list
                      .sort((a, b) => a.start_at_utc.localeCompare(b.start_at_utc))
                      .map((s) => {
                        const start = new Date(s.start_at_utc)
                        const end = new Date(start.getTime() + 60 * 60000)
                        const label = `${formatInTimeZone(start, TZ_JST, 'HH:mm')}–${formatInTimeZone(end, TZ_JST, 'HH:mm')}`
                        const hu = `${formatInTimeZone(start, TZ_HU, 'HH:mm')}–${formatInTimeZone(end, TZ_HU, 'HH:mm')}`
                        return (
                          <LinkButton key={s.id} href={`/book/${s.id}`} variant="primary">
                            {label}
                            <span className="ml-2 text-xs font-bold text-white/80">(HU {hu})</span>
                          </LinkButton>
                        )
                      })}
                  </div>
                </div>
              ))
          )}
        </div>
      </Card>
    </div>
  )
}
