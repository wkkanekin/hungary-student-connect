import { fetchTutorsWithOpenSlots } from '@/lib/db'
import { TutorSearch } from '@/components/tutor-search'

export default async function TutorsPage() {
  const { tutors, slots } = await fetchTutorsWithOpenSlots()
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-black">現役生を探す</h1>
        <p className="mt-1 text-slate-600">条件検索 → プロフィール → 空き枠予約（事前決済）</p>
      </div>

      <TutorSearch tutors={tutors} slots={slots} />
    </div>
  )
}
