'use client'

import { useState } from 'react'
import { supabaseBrowser } from '@/lib/supabase-browser'
import { Button, Card } from '@/components/ui'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const send = async () => {
    setError(null)
    const s = supabaseBrowser()
    const { error } = await s.auth.signInWithOtp({ email, options: { emailRedirectTo: `${window.location.origin}/dashboard` } })
    if (error) { setError(error.message); return }
    setSent(true)
  }

  return (
    <div className="mx-auto max-w-lg">
      <Card>
        <h1 className="text-xl font-black">現役生ログイン</h1>
        <p className="mt-1 text-sm text-slate-600">メールに届くリンク（マジックリンク）でログインします。</p>
        <div className="mt-4">
          <div className="text-xs font-bold text-slate-600">メールアドレス</div>
          <input className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
        {sent ? (
          <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
            ログインリンクを送信しました。メールを確認してください。
          </div>
        ) : (
          <Button className="mt-4 w-full" onClick={send} disabled={!email}>
            ログインリンクを送る
          </Button>
        )}
      </Card>
    </div>
  )
}
