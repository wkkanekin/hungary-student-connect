import { supabaseAdmin } from '@/lib/supabase-admin'
import { Card, LinkButton } from '@/components/ui'

export default async function CompletePage({ params }: { params: { reservationId: string } }) {
  const supabase = supabaseAdmin()
  const { data: r, error } = await supabase
    .from('reservations')
    .select('id,status,applicant_name,applicant_email,paid_at,tutor_id,slot_id')
    .eq('id', params.reservationId)
    .single()

  if (error) {
    return (
      <Card>
        <div className="font-extrabold">予約情報が見つかりませんでした</div>
        <p className="mt-2 text-sm text-slate-600">URLが古い可能性があります。</p>
        <div className="mt-4"><LinkButton href="/tutors">現役生を探す</LinkButton></div>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-black">予約が確定しました</h1>
        <p className="mt-1 text-slate-600">確認メールを送信しました（届かない場合は迷惑メールも確認してください）。</p>
      </div>

      <Card>
        <div className="text-sm text-slate-500">予約ID</div>
        <div className="font-mono text-sm">{r.id}</div>
        <div className="mt-3 grid gap-2 text-sm">
          <div><span className="text-slate-500">お名前：</span>{r.applicant_name}</div>
          <div><span className="text-slate-500">メール：</span>{r.applicant_email}</div>
          <div><span className="text-slate-500">ステータス：</span>{r.status}</div>
        </div>
      </Card>

      <div className="flex flex-wrap gap-3">
        <LinkButton href="/tutors" variant="secondary">別の現役生を見る</LinkButton>
        <LinkButton href="/">トップへ</LinkButton>
      </div>
    </div>
  )
}
