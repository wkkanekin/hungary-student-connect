-- Hungary Student Connect MVP schema
-- Run this in Supabase SQL editor.

-- Extensions
create extension if not exists pgcrypto;

-- 1) tutors
create table if not exists public.tutors (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now(),
  email text unique,
  name text not null,
  university text not null,
  region text not null check (region in ('Budapest','Countryside')),
  course text not null,
  field text not null,
  age_group text not null,
  work_years text not null,
  social_exp boolean not null default false,
  social_exp_detail text,
  style text not null default '気にしない',
  tags text[] not null default '{}'::text[],
  bio text not null default '',
  avatar_url text,
  active boolean not null default true,
  rating_avg numeric not null default 0,
  rating_count integer not null default 0,
  grade text
);

create index if not exists tutors_active_idx on public.tutors (active);

-- keep updated_at fresh
create or replace function public.set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists set_tutors_updated_at on public.tutors;
create trigger set_tutors_updated_at before update on public.tutors
for each row execute function public.set_updated_at();

-- 2) availability_slots
create table if not exists public.availability_slots (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone not null default now(),
  tutor_id uuid not null references public.tutors(id) on delete cascade,
  start_at_utc timestamp with time zone not null,
  end_at_utc timestamp with time zone not null,
  status text not null check (status in ('open','booked'))
);

create index if not exists slots_tutor_idx on public.availability_slots (tutor_id);
create index if not exists slots_status_idx on public.availability_slots (status);

-- 3) reservations
create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone not null default now(),
  tutor_id uuid not null references public.tutors(id) on delete restrict,
  slot_id uuid not null references public.availability_slots(id) on delete restrict,
  applicant_name text not null,
  applicant_email text not null,
  topics text[] not null default '{}'::text[],
  applicant_note text not null default '',
  applicant_status text not null default '',
  status text not null check (status in ('pending_payment','confirmed','canceled','refunded')),
  stripe_session_id text,
  paid_at timestamp with time zone
);

create index if not exists reservations_tutor_idx on public.reservations (tutor_id);
create index if not exists reservations_slot_idx on public.reservations (slot_id);
create index if not exists reservations_status_idx on public.reservations (status);

-- RLS
alter table public.tutors enable row level security;
alter table public.availability_slots enable row level security;
alter table public.reservations enable row level security;

-- Public read (applicant)
create policy "public can read active tutors" on public.tutors
for select using (active = true);

create policy "public can read open slots" on public.availability_slots
for select using (status = 'open');

-- Tutor self-management (authenticated)
-- Supabase Auth magic link creates authenticated users. We map tutor by email.
create policy "tutor can read own profile" on public.tutors
for select to authenticated
using (email = (auth.jwt() ->> 'email'));

create policy "tutor can update own profile" on public.tutors
for update to authenticated
using (email = (auth.jwt() ->> 'email'));

create policy "tutor can insert own slots" on public.availability_slots
for insert to authenticated
with check (tutor_id in (select id from public.tutors where email = (auth.jwt() ->> 'email')));

create policy "tutor can update own slots" on public.availability_slots
for update to authenticated
using (tutor_id in (select id from public.tutors where email = (auth.jwt() ->> 'email')));

create policy "tutor can delete own open slots" on public.availability_slots
for delete to authenticated
using (
  status = 'open'
  and tutor_id in (select id from public.tutors where email = (auth.jwt() ->> 'email'))
);

-- Reservations are managed server-side with service role (Stripe Webhook), so we don't need public insert/select.
-- Optional: allow tutor to read reservations related to them (for future).
create policy "tutor can read own reservations" on public.reservations
for select to authenticated
using (tutor_id in (select id from public.tutors where email = (auth.jwt() ->> 'email')));
