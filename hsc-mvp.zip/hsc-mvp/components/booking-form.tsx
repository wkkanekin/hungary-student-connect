'use client'

import { useState } from 'react'
import { Button } from '@/components/ui'

const TOPICS = [
  '留学全体の流れを知りたい',
  '大学・学部選び',
  '出願準備・書類',
  '奨学金（SHなど）',
  '現地生活（家賃・物価・治安）',
  '勉強・授業・試験、英語力',
  '将来（就職・進路）',
  'その他',
] as const

export function BookingForm({ slotId, tutorName }: { slotId: string; tutorName: string }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState('')
  const [note, setNote] = useState('')
  const [topics, setTopics] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const toggleTopic = (t: string) => {
    setTopics((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]))
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!name.trim() || !email.trim()) {
      setError('お名前とメールアドレスは必須です。')
      return
    }
    if (topics.length === 0) {
      setError('相談テーマを1つ以上選択してください。')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotId, name, email, status, note, topics }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data?.error ?? '決済の開始に失敗しました')
      window.location.href = data.url
    } catch (err: any) {
      setError(err.message ?? 'エラーが発生しました')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="text-sm text-slate-600">
        <span className="font-extrabold text-slate-900">{tutorName}</span> さんに事前に共有する内容です。
      </div>

      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}

      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <div className="text-xs font-bold text-slate-600">お名前（必須）</div>
          <input className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <div className="text-xs font-bold text-slate-600">メールアドレス（必須）</div>
          <input className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="example@email.com" />
        </div>
      </div>

      <div>
        <div className="text-xs font-bold text-slate-600">現状ステータス（任意）</div>
        <select className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">選択しない</option>
          <option value="高校生">高校生</option>
          <option value="大学生">大学生</option>
          <option value="社会人">社会人</option>
          <option value="その他">その他</option>
        </select>
      </div>

      <div>
        <div className="text-xs font-bold text-slate-600">相談テーマ（必須・複数可）</div>
        <div className="mt-2 grid gap-2">
          {TOPICS.map((t) => (
            <label key={t} className="flex items-start gap-2 rounded-xl border border-slate-200 bg-white p-3 text-sm">
              <input type="checkbox" className="mt-0.5" checked={topics.includes(t)} onChange={() => toggleTopic(t)} />
              <span className="text-slate-700">{t}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <div className="text-xs font-bold text-slate-600">今一番聞きたいこと（任意）</div>
        <textarea
          className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
          rows={4}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="例）SHの志望動機をどう書いたか／医学部の勉強量はどれくらいか／生活費は月いくらかかるか"
        />
        <div className="mt-1 text-xs text-slate-500">書けない場合は空欄でOK</div>
      </div>

      <Button type="submit" disabled={loading}>
        {loading ? '決済画面へ…' : '8,000円で予約して決済へ'}
      </Button>

      <p className="text-xs text-slate-500">事前決済制です。現役生側の都合で実施できない場合は全額返金します。</p>
    </form>
  )
}
