import Link from 'next/link'

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/80 backdrop-blur">
      <div className="mx-auto flex w-[92vw] max-w-6xl items-center justify-between py-3">
        <Link href="/" className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-slate-900 text-white font-black">
            H
          </div>
          <div className="leading-tight">
            <div className="font-extrabold">ハンガリー現役生名鑑</div>
            <div className="text-xs text-slate-500">ベータ版</div>
          </div>
        </Link>

        <nav className="flex items-center gap-2 text-sm">
          <Link href="/tutors" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            現役生を探す
          </Link>
          <Link href="/pricing" className="rounded-xl px-3 py-2 hover:bg-slate-100">
            料金
          </Link>
          <Link href="/login" className="rounded-xl bg-slate-900 px-3 py-2 text-white hover:bg-slate-800">
            現役生ログイン
          </Link>
        </nav>
      </div>
    </header>
  )
}
