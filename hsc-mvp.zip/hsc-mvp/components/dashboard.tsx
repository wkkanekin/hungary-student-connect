'use client'

import { useEffect, useMemo, useState } from 'react'
import { supabaseBrowser } from '@/lib/supabase-browser'
import { Button, Card, Badge } from '@/components/ui'
import { TZ_HU, TZ_JST } from '@/lib/time'
import { formatInTimeZone } from 'date-fns-tz'

type Slot = {
  id: string
  tutor_id: string
  start_at_utc: string
  end_at_utc: string
  status: 'open' | 'booked'
}

type Tutor = {
  id: string
  email: string
  name: string
  university: string
  region: 'Budapest' | 'Countryside'
  course: string
  field: string
  age_group: string
  work_years: string
  social_exp: boolean
  social_exp_detail?: string | null
  style: string
  bio: string
  tags: string[]
  avatar_url?: string | null
}

const pad = (n: number) => String(n).padStart(2, '0')

function addDays(d: Date, days: number) {
  const x = new Date(d)
  x.setDate(x.getDate() + days)
  return x
}

function isoDateHu(d: Date) {
  return formatInTimeZone(d, TZ_HU, 'yyyy-MM-dd')
}

function timeOpts() {
  const out: string[] = []
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += 30) out.push(`${pad(h)}:${pad(m)}`)
  }
  return out
}

export function Dashboard({ email }: { email: string }) {
  const supabase = useMemo(() => supabaseBrowser(), [])
  const [tutor, setTutor] = useState<Tutor | null>(null)
  const [slots, setSlots] = useState<Slot[]>([])
  const [loading, setLoading] = useState(true)
  const [msg, setMsg] = useState<string | null>(null)
  const [err, setErr] = useState<string | null>(null)

  // add slot form
  const [date, setDate] = useState(isoDateHu(new Date()))
  const [start, setStart] = useState('18:00')

  useEffect(() => {
    ;(async () => {
      setLoading(true)
      setErr(null)

      // tutor lookup by email
      const { data: t, error: tErr } = await supabase
        .from('tutors')
        .select('*')
        .eq('email', email)
        .single()

      if (tErr) {
        setErr('このメールアドレスに紐づく現役生が未登録です。運営が招待・登録する必要があります。')
        setLoading(false)
        return
      }

      setTutor(t as any)

      const { data: s, error: sErr } = await supabase
        .from('availability_slots')
        .select('*')
        .eq('tutor_id', (t as any).id)
        .order('start_at_utc', { ascending: true })

      if (sErr) setErr(sErr.message)
      setSlots((s as any) || [])
      setLoading(false)
    })()
  }, [supabase, email])

  const timeOptions = useMemo(() => timeOpts(), [])

  const addSlot = async () => {
    if (!tutor) return
    setMsg(null)
    setErr(null)

    // input is HU local; store UTC
    const startHu = new Date(`${date}T${start}:00`)
    // startHu is interpreted as local timezone of browser; not reliable. We'll send to RPC server to convert.
    const res = await fetch('/api/slots/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tutorId: tutor.id, date, start })
    })
    const json = await res.json()
    if (!res.ok) {
      setErr(json.error || '追加に失敗しました')
      return
    }
    setSlots((prev) => [json.slot, ...prev].sort((a, b) => a.start_at_utc.localeCompare(b.start_at_utc)))
    setMsg('空き枠を追加しました')
  }

  const removeSlot = async (slotId: string) => {
    if (!confirm('この空き枠を削除しますか？')) return
    const res = await fetch('/api/slots/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ slotId })
    })
    const json = await res.json()
    if (!res.ok) {
      setErr(json.error || '削除に失敗しました')
      return
    }
    setSlots((prev) => prev.filter((s) => s.id !== slotId))
    setMsg('削除しました')
  }

  const updateProfile = async (patch: Partial<Tutor>) => {
    if (!tutor) return
    setMsg(null)
    setErr(null)
    const { data, error } = await supabase.from('tutors').update(patch).eq('id', tutor.id).select('*').single()
    if (error) {
      setErr(error.message)
      return
    }
    setTutor(data as any)
    setMsg('プロフィールを保存しました')
  }

  const uploadAvatar = async (file: File) => {
    if (!tutor) return
    setMsg(null)
    setErr(null)

    const ext = file.name.split('.').pop() || 'png'
    const path = `${tutor.id}/${Date.now()}.${ext}`
    const { error: upErr } = await supabase.storage.from('avatars').upload(path, file, { upsert: true })
    if (upErr) {
      setErr(upErr.message)
      return
    }
    const { data } = supabase.storage.from('avatars').getPublicUrl(path)
    await updateProfile({ avatar_url: data.publicUrl })
  }

  if (loading) {
    return <div className="text-slate-600">読み込み中...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black">現役生ダッシュボード</h1>
        <p className="mt-1 text-slate-600">空き枠は <b>ブダペスト時間</b> で入力します。志願者には日本時間で表示されます。</p>
      </div>

      {msg && <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{msg}</div>}
      {err && <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{err}</div>}

      {!tutor ? (
        <Card>
          <div className="font-extrabold">まずは運営が現役生を登録する必要があります</div>
          <p className="mt-2 text-sm text-slate-600">あなたのメール（{email}）を tutors テーブルに登録してください。</p>
        </Card>
      ) : (
        <>
          <Card>
            <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
              <div>
                <div className="text-xs font-bold text-slate-500">プロフィール</div>
                <div className="mt-1 text-lg font-black">{tutor.name}</div>
                <div className="mt-1 text-sm text-slate-600">{tutor.university} / {tutor.region === 'Budapest' ? 'ブダペスト' : '地方'}</div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Badge>{tutor.course}</Badge>
                  <Badge>{tutor.field}</Badge>
                  <Badge>{tutor.age_group}</Badge>
                  <Badge>{tutor.work_years}</Badge>
                  <Badge>{tutor.social_exp ? '社会人経験あり' : '社会人経験なし'}</Badge>
                </div>
              </div>

              <div className="w-full md:w-80">
                <div className="text-xs font-bold text-slate-500">アバター（任意）</div>
                <input
                  type="file"
                  accept="image/*"
                  className="mt-2 w-full text-sm"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) uploadAvatar(file)
                  }}
                />
                <p className="mt-1 text-xs text-slate-500">Supabase Storage の avatars バケットを使用します。</p>
              </div>
            </div>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <label className="block">
                <div className="text-xs font-bold text-slate-600">一言紹介（1〜2行）</div>
                <input
                  value={tutor.bio}
                  onChange={(e) => setTutor({ ...tutor, bio: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
                />
              </label>
              <label className="block">
                <div className="text-xs font-bold text-slate-600">相談ジャンル（カンマ区切り）</div>
                <input
                  value={tutor.tags.join(',')}
                  onChange={(e) => setTutor({ ...tutor, tags: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
                />
              </label>
            </div>

            <div className="mt-4">
              <Button onClick={() => updateProfile({ bio: tutor.bio, tags: tutor.tags })}>プロフィールを保存</Button>
            </div>
          </Card>

          <Card>
            <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
              <div>
                <div className="text-lg font-black">空き枠を追加</div>
                <p className="mt-1 text-sm text-slate-600">入力はブダペスト時間。1枠60分（終了は自動）。</p>
              </div>
              <div className="grid w-full gap-2 md:w-auto md:grid-cols-[180px_160px_160px]">
                <div>
                  <div className="text-xs font-bold text-slate-600">日付（ブダペスト）</div>
                  <input
                    type="date"
                    value={date}
                    min={isoDateHu(new Date())}
                    max={isoDateHu(addDays(new Date(), 7))}
                    onChange={(e) => setDate(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
                  />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-600">開始（30分刻み）</div>
                  <select
                    value={start}
                    onChange={(e) => setStart(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
                  >
                    {timeOptions.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="md:self-end">
                  <Button onClick={addSlot} className="w-full">空き枠を追加</Button>
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-2">
              {slots.length === 0 ? (
                <div className="text-sm text-slate-600">まだ空き枠がありません。</div>
              ) : (
                slots.map((s) => {
                  const startJ = formatInTimeZone(new Date(s.start_at_utc), TZ_JST, 'M/d(EEE) HH:mm')
                  const startH = formatInTimeZone(new Date(s.start_at_utc), TZ_HU, 'M/d(EEE) HH:mm')
                  const endJ = formatInTimeZone(new Date(s.end_at_utc), TZ_JST, 'HH:mm')
                  const endH = formatInTimeZone(new Date(s.end_at_utc), TZ_HU, 'HH:mm')
                  return (
                    <div key={s.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                        <div>
                          <div className="text-sm font-extrabold">{startH}–{endH}（ブダペスト）</div>
                          <div className="text-xs text-slate-600">志願者表示：{startJ}–{endJ}（日本）</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge>{s.status === 'open' ? 'open' : 'booked'}</Badge>
                          {s.status === 'open' ? (
                            <button
                              onClick={() => removeSlot(s.id)}
                              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100"
                            >
                              削除
                            </button>
                          ) : (
                            <span className="text-xs text-slate-500">予約済みは削除できません</span>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </Card>
        </>
      )}
    </div>
  )
}
