'use client'

import { useMemo, useState } from 'react'
import type { AvailabilitySlot, Tutor } from '@/lib/types'
import { Badge, Card, LinkButton } from '@/components/ui'
import { UNIVERSITIES } from '@/lib/universities'
import { TZ_HU, TZ_JST } from '@/lib/time'
import { formatInTimeZone } from 'date-fns-tz'

type Props = { tutors: Tutor[]; slots: AvailabilitySlot[] }

type Filters = {
  date: string // YYYY-MM-DD (JST)
  startTime: string // HH:mm (JST)
  university: string
  region: '' | 'Budapest' | 'Countryside'
  sex: '' | '男性' | '女性'
  age: '' | '10代' | '20代' | '30代' | '40代以上'
  course: '' | '予備' | '学部' | '修士' | '博士'
  field: '' | '文系' | '理系' | '医学部' | '芸術系' | 'その他'
  style: '' | '音声のみ' | 'ビデオ' | 'カメラOFF' | '気にしない'
  workYears: '' | 'なし' | '1年未満' | '1–3年' | '3–5年' | '5年以上'
  grade: string
}

const todayJst = () => {
  const d = new Date()
  return formatInTimeZone(d, TZ_JST, 'yyyy-MM-dd')
}

const timeOptions = () => {
  const out: string[] = []
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += 30) {
      const hh = String(h).padStart(2, '0')
      const mm = String(m).padStart(2, '0')
      out.push(`${hh}:${mm}`)
    }
  }
  return out
}

function sameJstStart(slotUtc: string, date: string, startTime: string) {
  const slotDate = formatInTimeZone(new Date(slotUtc), TZ_JST, 'yyyy-MM-dd')
  const slotTime = formatInTimeZone(new Date(slotUtc), TZ_JST, 'HH:mm')
  return slotDate === date && slotTime === startTime
}

function jstRangeWithHu(slotUtc: string, minutes = 60) {
  const start = new Date(slotUtc)
  const end = new Date(start.getTime() + minutes * 60000)
  const jDate = formatInTimeZone(start, TZ_JST, 'M/d(EEE)')
  const jStart = formatInTimeZone(start, TZ_JST, 'HH:mm')
  const jEnd = formatInTimeZone(end, TZ_JST, 'HH:mm')
  const hStart = formatInTimeZone(start, TZ_HU, 'HH:mm')
  const hEnd = formatInTimeZone(end, TZ_HU, 'HH:mm')
  return `${jDate} ${jStart}–${jEnd}（日本） / ${hStart}–${hEnd}（ハンガリー）`
}

export function TutorSearch({ tutors, slots }: Props) {
  const [filters, setFilters] = useState<Filters>({
    date: todayJst(),
    startTime: '20:00',
    university: '',
    region: '',
    sex: '',
    age: '',
    course: '',
    field: '',
    style: '',
    workYears: '',
    grade: '',
  })

  const optionsTime = useMemo(() => timeOptions(), [])

  const filtered = useMemo(() => {
    const openSlots = slots.filter((s) => s.status === 'open')

    // tutorId -> matching slots
    const slotsByTutor = new Map<string, AvailabilitySlot[]>()
    for (const s of openSlots) {
      const arr = slotsByTutor.get(s.tutor_id) ?? []
      arr.push(s)
      slotsByTutor.set(s.tutor_id, arr)
    }

    const activeTutors = tutors.filter((t) => t.active)

    const scored = activeTutors
      .map((t) => {
        const mySlots = (slotsByTutor.get(t.id) ?? []).slice().sort((a, b) => a.start_at_utc.localeCompare(b.start_at_utc))

        // time filter: startが一致する枠がある人を優先（未指定なら全員）
        const hasExactTime = filters.date && filters.startTime
          ? mySlots.some((s) => sameJstStart(s.start_at_utc, filters.date, filters.startTime))
          : true

        // basic filtering
        if (filters.region && t.region !== filters.region) return null
        if (filters.university && !t.university.includes(filters.university)) return null
        if (filters.sex && (t as any).sex !== filters.sex) return null // optional field
        if (filters.age && t.age_group !== filters.age) return null
        if (filters.course && t.course !== filters.course) return null
        if (filters.field && t.field !== filters.field) return null
        if (filters.style && t.style !== filters.style) return null
        if (filters.workYears && t.work_years !== filters.workYears) return null
        if (filters.grade && (t.grade ?? '') !== filters.grade) return null

        // match score (apps除外)
        const checks: Array<[boolean, string]> = []
        if (filters.region) checks.push([t.region === filters.region, '地域'])
        if (filters.university) checks.push([t.university.includes(filters.university), '大学'])
        if (filters.age) checks.push([t.age_group === filters.age, '年齢'])
        if (filters.course) checks.push([t.course === filters.course, '課程'])
        if (filters.field) checks.push([t.field === filters.field, '系統'])
        if (filters.workYears) checks.push([t.work_years === filters.workYears, '社会人歴'])
        if (filters.grade) checks.push([(t.grade ?? '') === filters.grade, '学年'])

        const denom = checks.length || 1
        const numer = checks.filter(([ok]) => ok).length

        const nextSlot = mySlots[0]
        const exactSlot = mySlots.find((s) => sameJstStart(s.start_at_utc, filters.date, filters.startTime))

        return {
          tutor: t,
          nextSlot,
          exactSlot,
          hasExactTime,
          numer,
          denom,
        }
      })
      .filter(Boolean) as Array<{
        tutor: Tutor
        nextSlot?: AvailabilitySlot
        exactSlot?: AvailabilitySlot
        hasExactTime: boolean
        numer: number
        denom: number
      }>

    // ordering: hasExactTime first, then match score desc
    scored.sort((a, b) => {
      if (a.hasExactTime !== b.hasExactTime) return a.hasExactTime ? -1 : 1
      if (a.numer !== b.numer) return b.numer - a.numer
      return (a.nextSlot?.start_at_utc ?? '').localeCompare(b.nextSlot?.start_at_utc ?? '')
    })

    return scored
  }, [tutors, slots, filters])

  const hit = filtered.length

  const reset = () =>
    setFilters({
      date: todayJst(),
      startTime: '20:00',
      university: '',
      region: '',
      sex: '',
      age: '',
      course: '',
      field: '',
      style: '',
      workYears: '',
      grade: '',
    })

  // university suggestions
  const uniCandidates = useMemo(() => {
    const kw = filters.university.trim()
    const base = filters.region ? UNIVERSITIES.filter((u) => u.region === filters.region) : UNIVERSITIES
    if (!kw) return base.slice(0, 8)
    return base.filter((u) => u.name.toLowerCase().includes(kw.toLowerCase())).slice(0, 8)
  }, [filters.university, filters.region])

  return (
    <div className="grid gap-4 lg:grid-cols-[360px_1fr]">
      <aside className="space-y-4">
        <Card>
          <div className="font-extrabold">予約・現役生検索</div>
          <p className="mt-1 text-xs text-slate-500">※表示は日本時間（JST）です。検索結果にハンガリー時間も併記します。</p>

          <div className="mt-4 grid gap-3">
            <div>
              <div className="text-xs font-bold text-slate-600">日付（日本時間）</div>
              <input
                type="date"
                value={filters.date}
                onChange={(e) => setFilters((f) => ({ ...f, date: e.target.value }))}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
              />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-600">開始時間（日本時間）</div>
              <select
                value={filters.startTime}
                onChange={(e) => setFilters((f) => ({ ...f, startTime: e.target.value }))}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
              >
                {optionsTime.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
              <div className="mt-1 text-xs text-slate-500">終了時間は開始＋60分で固定</div>
            </div>

            <div>
              <div className="text-xs font-bold text-slate-600">地域</div>
              <div className="mt-2 flex gap-2">
                {([
                  ['', '指定なし'],
                  ['Budapest', 'ブダペスト'],
                  ['Countryside', '地方'],
                ] as const).map(([val, label]) => (
                  <button
                    key={val}
                    onClick={() => setFilters((f) => ({ ...f, region: val as any }))}
                    className={`rounded-xl border px-3 py-2 text-xs font-bold ${filters.region === val ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                    type="button"
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="mt-2 text-xs text-slate-500">
                <div>ブダペスト：仕事・インターン多め / 生活費高め</div>
                <div>地方：生活費を抑えやすい / 落ち着いた環境</div>
              </div>
            </div>

            <div>
              <div className="text-xs font-bold text-slate-600">大学名（サジェスト）</div>
              <input
                value={filters.university}
                onChange={(e) => setFilters((f) => ({ ...f, university: e.target.value }))}
                placeholder="例：ELTE / Semmelweis"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
              />
              {uniCandidates.length > 0 && (
                <div className="mt-2 rounded-xl border border-slate-200 bg-white p-2">
                  {uniCandidates.map((u) => (
                    <button
                      key={u.name}
                      type="button"
                      onClick={() => setFilters((f) => ({ ...f, university: u.name }))}
                      className="block w-full rounded-lg px-2 py-2 text-left text-xs hover:bg-slate-50"
                    >
                      {u.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Select label="年齢" value={filters.age} onChange={(v) => setFilters((f) => ({ ...f, age: v as any }))} options={['', '10代', '20代', '30代', '40代以上']} />
              <Select label="課程" value={filters.course} onChange={(v) => setFilters((f) => ({ ...f, course: v as any }))} options={['', '予備', '学部', '修士', '博士']} />
              <Select label="系統" value={filters.field} onChange={(v) => setFilters((f) => ({ ...f, field: v as any }))} options={['', '文系', '理系', '医学部', '芸術系', 'その他']} />
              <Select label="希望スタイル" value={filters.style} onChange={(v) => setFilters((f) => ({ ...f, style: v as any }))} options={['', '音声のみ', 'ビデオ', 'カメラOFF', '気にしない']} />
              <Select label="社会人歴" value={filters.workYears} onChange={(v) => setFilters((f) => ({ ...f, workYears: v as any }))} options={['', 'なし', '1年未満', '1–3年', '3–5年', '5年以上']} />
              <Select label="学年（任意）" value={filters.grade} onChange={(v) => setFilters((f) => ({ ...f, grade: v }))} options={['', '1年', '2年', '3年', '4年', '修士1年', '修士2年', '博士']} />
            </div>

            <button type="button" onClick={reset} className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-extrabold hover:bg-slate-50">
              条件をクリア
            </button>
          </div>
        </Card>
      </aside>

      <div className="space-y-3">
        <div className="flex items-end justify-between gap-3">
          <div>
            <div className="text-sm text-slate-600">{hit}件の相談者が見つかりました</div>
            <div className="text-xs text-slate-500">初期表示は「おすすめ順（マッチ数）」です。</div>
          </div>
        </div>

        {filtered.map(({ tutor, nextSlot, exactSlot, numer, denom }) => {
          const slotToShow = exactSlot ?? nextSlot
          return (
            <Card key={tutor.id} className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex gap-4">
                  <div className="grid h-14 w-14 place-items-center rounded-2xl border border-slate-200 bg-slate-50 text-sm font-black text-slate-700">
                    {tutor.name.slice(0, 1)}
                  </div>
                  <div>
                    <div className="text-base font-extrabold">{tutor.name}</div>
                    <div className="mt-1 text-xs text-slate-600">{tutor.university}</div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Badge>{tutor.region === 'Budapest' ? 'ブダペスト' : '地方'}</Badge>
                      <Badge>{tutor.course}</Badge>
                      <Badge>{tutor.field}</Badge>
                      <Badge>{tutor.social_exp ? '社会人経験あり' : '社会人経験なし'}</Badge>
                      <Badge>{tutor.age_group}</Badge>
                      {tutor.grade ? <Badge>{tutor.grade}</Badge> : null}
                    </div>
                  </div>
                </div>

                <LinkButton href={`/tutors/${tutor.id}`} variant="primary">
                  予約する
                </LinkButton>
              </div>

              <p className="mt-3 text-sm text-slate-700">{tutor.bio}</p>

              <div className="mt-3 flex flex-wrap gap-2">
                {tutor.tags.slice(0, 6).map((tag) => (
                  <Badge key={tag} className="bg-slate-50">
                    {tag}
                  </Badge>
                ))}
              </div>

              <div className="mt-4 grid gap-2 text-sm">
                <div className="text-slate-600">
                  <span className="font-bold">マッチ度：</span>
                  {numer}/{denom}（※アプリ除外）
                </div>
                {slotToShow ? (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-slate-700">
                    次の空き：{jstRangeWithHu(slotToShow.start_at_utc)}
                  </div>
                ) : (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-slate-600">
                    現在、空き枠がありません（現役生が追加すると表示されます）
                  </div>
                )}
              </div>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  options: string[]
}) {
  return (
    <div>
      <div className="text-xs font-bold text-slate-600">{label}</div>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm"
      >
        {options.map((o) => (
          <option key={o || 'none'} value={o}>
            {o || '指定なし'}
          </option>
        ))}
      </select>
    </div>
  )
}
