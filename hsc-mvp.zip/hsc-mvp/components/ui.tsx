import { clsx } from 'clsx'
import Link from 'next/link'
import type { ComponentProps } from 'react'

export function Button(props: ComponentProps<'button'> & { variant?: 'primary' | 'secondary' }) {
  const { variant = 'primary', className, ...rest } = props
  return (
    <button
      {...rest}
      className={clsx(
        'inline-flex items-center justify-center rounded-xl px-4 py-3 text-sm font-extrabold transition',
        variant === 'primary' ? 'bg-slate-900 text-white hover:bg-slate-800' : 'border border-slate-200 bg-white hover:bg-slate-50',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        className
      )}
    />
  )
}

export function LinkButton(props: ComponentProps<typeof Link> & { variant?: 'primary' | 'secondary' }) {
  const { variant = 'primary', className, ...rest } = props
  return (
    <Link
      {...rest}
      className={clsx(
        'inline-flex items-center justify-center rounded-xl px-4 py-3 text-sm font-extrabold transition',
        variant === 'primary' ? 'bg-slate-900 text-white hover:bg-slate-800' : 'border border-slate-200 bg-white hover:bg-slate-50',
        className
      )}
    />
  )
}

export function Badge({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={clsx('inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-bold text-slate-700', className)}>
      {children}
    </span>
  )
}

export function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={clsx('rounded-2xl border border-slate-200 bg-white p-5 shadow-sm', className)}>
      {children}
    </div>
  )
}
