import Link from 'next/link'

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto flex w-[92vw] max-w-6xl flex-col gap-3 py-6 text-sm text-slate-500 md:flex-row md:items-center md:justify-between">
        <div>© Hungary Student Connect（ベータ版）</div>
        <div className="flex flex-wrap gap-4">
          <Link className="hover:text-slate-900" href="/">トップ</Link>
          <Link className="hover:text-slate-900" href="/tutors">現役生</Link>
          <Link className="hover:text-slate-900" href="/pricing">料金</Link>
          <Link className="hover:text-slate-900" href="/terms">利用規約</Link>
          <Link className="hover:text-slate-900" href="/privacy">プライバシー</Link>
        </div>
      </div>
    </footer>
  )
}
