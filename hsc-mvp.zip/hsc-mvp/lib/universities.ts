import type { Region } from '@/lib/types'

export type University = { name: string; region: Region }

// ここだけ編集：大学リスト（必要に応じて追加）
export const UNIVERSITIES: University[] = [
  { name: 'Eötvös Loránd University（ELTE）', region: 'Budapest' },
  { name: 'Budapest University of Technology and Economics（BME）', region: 'Budapest' },
  { name: 'Semmelweis University', region: 'Budapest' },
  { name: 'Corvinus University of Budapest', region: 'Budapest' },
  { name: 'University of Debrecen', region: 'Countryside' },
  { name: 'University of Pécs', region: 'Countryside' }
]
