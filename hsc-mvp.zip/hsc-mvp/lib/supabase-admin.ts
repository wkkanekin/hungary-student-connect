import { createClient } from '@supabase/supabase-js'
import { env } from '@/lib/env'

export function supabaseAdmin() {
  if (!env.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('SUPABASE_SERVICE_ROLE_KEY が未設定です（Stripe Webhook等のサーバ処理に必要）')
  }
  return createClient(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false }
  })
}
