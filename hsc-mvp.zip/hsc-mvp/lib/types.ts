export type Region = 'Budapest' | 'Countryside'

export type Tutor = {
  id: string
  email?: string
  name: string
  university: string
  region: Region
  course: string
  field: string
  age_group: string
  work_years: string
  social_exp: boolean
  social_exp_detail?: string | null
  style: string
  bio: string
  tags: string[]
  avatar_url?: string | null
  active: boolean
  rating_avg: number
  rating_count: number
  grade?: string | null
}

export type AvailabilitySlot = {
  id: string
  tutor_id: string
  start_at_utc: string
  end_at_utc: string
  status: 'open' | 'booked'
}

export type Reservation = {
  id: string
  tutor_id: string
  slot_id: string
  applicant_name: string
  applicant_email: string
  topics: string[]
  applicant_note: string
  applicant_status: string
  status: 'pending_payment' | 'confirmed' | 'canceled' | 'refunded'
  stripe_session_id?: string
  paid_at?: string | null
}
