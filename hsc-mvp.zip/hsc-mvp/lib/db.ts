import { supabaseServer } from '@/lib/supabase-server'
import type { AvailabilitySlot, Tutor } from '@/lib/types'

export async function fetchTutorsWithOpenSlots() {
  const supabase = supabaseServer()
  const { data: tutors, error: tErr } = await supabase
    .from('tutors')
    .select('*')
    .eq('active', true)
    .order('created_at', { ascending: false })

  if (tErr) throw tErr

  const { data: slots, error: sErr } = await supabase
    .from('availability_slots')
    .select('*')
    .eq('status', 'open')

  if (sErr) throw sErr

  return {
    tutors: (tutors || []) as Tutor[],
    slots: (slots || []) as AvailabilitySlot[]
  }
}

export async function fetchTutorById(id: string) {
  const supabase = supabaseServer()
  const { data, error } = await supabase.from('tutors').select('*').eq('id', id).single()
  if (error) throw error
  return data as Tutor
}

export async function fetchOpenSlotsForTutor(tutorId: string) {
  const supabase = supabaseServer()
  const { data, error } = await supabase
    .from('availability_slots')
    .select('*')
    .eq('tutor_id', tutorId)
    .eq('status', 'open')
    .order('start_at_utc', { ascending: true })
  if (error) throw error
  return (data || []) as AvailabilitySlot[]
}

export async function fetchSlot(slotId: string) {
  const supabase = supabaseServer()
  const { data, error } = await supabase
    .from('availability_slots')
    .select('*')
    .eq('id', slotId)
    .single()
  if (error) throw error
  return data as AvailabilitySlot
}
