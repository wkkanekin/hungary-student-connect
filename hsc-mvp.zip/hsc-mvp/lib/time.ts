import { formatInTimeZone, zonedTimeToUtc, utcToZonedTime } from 'date-fns-tz'

export const TZ_JST = 'Asia/Tokyo'
export const TZ_HU = 'Europe/Budapest'

export function formatJst(d: Date, fmt = 'M/d(eee) HH:mm') {
  return formatInTimeZone(d, TZ_JST, fmt, { locale: undefined as any })
}

export function formatHu(d: Date, fmt = 'M/d(eee) HH:mm') {
  return formatInTimeZone(d, TZ_HU, fmt, { locale: undefined as any })
}

export function huLocalToUtcISO(huLocalISO: string) {
  // huLocalISO: '2026-01-20T10:30'
  const utc = zonedTimeToUtc(huLocalISO, TZ_HU)
  return utc.toISOString()
}

export function utcISOToZonedDate(utcISO: string, tz: string) {
  return utcToZonedTime(new Date(utcISO), tz)
}

export function addMinutesISO(utcISO: string, minutes: number) {
  const d = new Date(utcISO)
  d.setMinutes(d.getMinutes() + minutes)
  return d.toISOString()
}
